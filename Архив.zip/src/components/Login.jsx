import React from "react";
import { Field, reduxForm } from "redux-form";
import {required}  from './validators/validators'

const Login = (props) => {
    const onSubmit = (DATAForm) => {
        console.log(DATAForm)
    }

    return (
        <div>
            <h1>LOGIN</h1>
            <LoginReduxForm onSubmit={onSubmit}/>
        </div>
    )
}

export default Login;

const LoginForm = props => {
    return (
        <form onSubmit={props.handleSubmit}>
            <div>
                <Field validate={[required]} component={'input'} name={'login'} placeholder={"Login"} />
            </div>
            <div>
                <Field validate={[required]} component={'input'} name={'password'} placeholder={"Password"} />
            </div>
            <div>
                <Field validate={[required]} component={'input'} type={'checkbox'} name={'rememberMe'} />
            </div>
            <button >Submit</button>
        </form>
    )
}



const LoginReduxForm = reduxForm({form: 'login'})(LoginForm)