import React from "react";
import prices from "./Prices.module.scss"

const Prices = () => {
    return (
        <div className={prices.prices}>
           
        </div>
    )
}

export default Prices